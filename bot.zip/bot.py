"""Telegram-бот «Подбор жилых комплексов» — версия сайта на aiogram 3."""
from __future__ import annotations

import asyncio
import html
import logging
import os
import re
import sys
from pathlib import Path

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from table import Complex, TableStore, apply_filters, estimate

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # .env необязателен
    pass

DEFAULT_CSV_URL = (
    "https://docs.google.com/spreadsheets/d/e/2PACX-1vRidRYz_zjvCfka0s0yXsTGK7e5ca6h3ck8Iv3ic4y37yx1tMRO9_iiwi3ef4OjWOIRaYnmySU5YoiH/"
    "pub?gid=0&single=true&output=csv"
)
PAGE_SIZE = 3
router = Router()


class Form(StatesGroup):
    price = State()
    floors = State()
    ceiling = State()
    area = State()
    budget = State()


# Числовые параметры: ключ -> (название, единица, подсказка с примерами)
RANGES = {
    "price": ("Цена за м²", "₽", "Например: <code>200000-500000</code>, <code>от 300000</code> или <code>до 400000</code>"),
    "floors": ("Этажность", "эт.", "Например: <code>10-20</code>, <code>от 15</code> или <code>до 9</code>"),
    "ceiling": ("Высота потолков", "м", "Например: <code>2.7-3.5</code>, <code>от 3</code> или <code>до 3,2</code>"),
}
# Одиночные параметры: ключ -> (название, единица, подсказка)
SINGLES = {
    "area": ("Желаемая площадь", "м²", "Например: <code>45</code> или <code>38,5</code>. По площади считается примерная стоимость квартиры."),
    "budget": ("Бюджет на квартиру", "млн ₽", "Максимум в миллионах рублей. Например: <code>15</code>, <code>12,5</code> или <code>15 000 000</code>."),
}
META = {**{k: (v[0], v[1], v[2]) for k, v in RANGES.items()}, **SINGLES}
STATES = {f"Form:{k}": k for k in META}
EMPTY = {"city": None, "house": None, "price": [None, None], "floors": [None, None], "ceiling": [None, None], "area": None, "budget": None}


# ───────────────────────── форматирование ─────────────────────────
def fmt_num(n: float, key: str) -> str:
    if key == "ceiling":
        return f"{n:g}".replace(".", ",")
    return f"{int(n):,}".replace(",", " ") if float(n).is_integer() else f"{n:g}"


def fmt_range(rng: list, key: str) -> str:
    lo, hi = rng
    unit = RANGES[key][1]
    if lo is None and hi is None:
        return "любая"
    if lo is None:
        return f"до {fmt_num(hi, key)} {unit}"
    if hi is None:
        return f"от {fmt_num(lo, key)} {unit}"
    return f"{fmt_num(lo, key)} – {fmt_num(hi, key)} {unit}"


def fmt_m(n: float) -> str:
    """Миллионы рублей: 20.0745 -> «20,07»."""
    return f"{n:.2f}".rstrip("0").rstrip(".").replace(".", ",")


def fmt_single(v: float | None, key: str) -> str:
    if v is None:
        return "не задана" if key == "area" else "не задан"
    return f"{fmt_m(v)} {SINGLES[key][1]}"


def parse_single(text: str, key: str) -> float:
    """'45' / '38,5 м' -> 45 / 38.5; для бюджета '15 млн' или '15 000 000' -> 15 (млн ₽). ValueError при ошибке."""
    t = text.strip().lower().replace(",", ".")
    t = re.sub(r"(?<=\d)[ \u00a0](?=\d{3}(?!\d))", "", t)
    m = re.search(r"\d+(?:\.\d+)?", t)
    if not m:
        raise ValueError
    n = float(m.group())
    if key == "budget" and n >= 10000:  # ввели в рублях
        n /= 1e6
    if n <= 0:
        raise ValueError
    return n


def plural(n: int) -> str:
    if 11 <= n % 100 <= 14:
        return "жилых комплексов"
    return {1: "жилой комплекс", 2: "жилых комплекса", 3: "жилых комплекса", 4: "жилых комплекса"}.get(n % 10, "жилых комплексов")


def parse_user_range(text: str) -> list[float | None]:
    """'200000-500000' / 'от 3' / 'до 3,2' -> [lo, hi]. ValueError, если не удалось разобрать."""
    t = text.strip().lower().replace(",", ".")
    t = re.sub(r"(?<=\d)[ \u00a0](?=\d{3}(?!\d))", "", t)  # «200 000» -> «200000»
    nums = [float(x) for x in re.findall(r"\d+(?:\.\d+)?", t)]
    if not nums or len(nums) > 2:
        raise ValueError
    if len(nums) == 2:
        lo, hi = sorted(nums)
        return [lo, hi]
    n = nums[0]
    if t.startswith("до") or re.match(r"\s*[-–—]", t):
        return [None, n]
    return [n, None]  # «от N» или просто число


def e(v: str | None, empty: str = "нет данных") -> str:
    return html.escape(v) if v else empty


# ───────────────────────── экраны ─────────────────────────
async def get_filters(state: FSMContext) -> dict:
    data = await state.get_data()
    return {k: data.get(k, v) for k, v in EMPTY.items()}


def menu_text(f: dict, store: TableStore) -> str:
    status = (
        f"Таблица синхронизирована · {store.updated}"
        if store.live
        else "Используется локальная копия таблицы (Google недоступен)"
    )
    return (
        "🏠 <b>Подбор жилых комплексов</b>\n"
        "Задайте параметры и нажмите «Найти». Незаполненные параметры не учитываются.\n\n"
        f"🏙 Город: <b>{html.escape(f['city']) if f['city'] else 'все города'}</b>\n"
        f"💰 Цена за м²: <b>{fmt_range(f['price'], 'price')}</b>\n"
        f"🏢 Этажность: <b>{fmt_range(f['floors'], 'floors')}</b>\n"
        f"🧱 Тип дома: <b>{html.escape(f['house']) if f['house'] else 'любой'}</b>\n"
        f"↕️ Высота потолков: <b>{fmt_range(f['ceiling'], 'ceiling')}</b>\n"
        f"📐 Желаемая площадь: <b>{fmt_single(f['area'], 'area')}</b>\n"
        f"💼 Бюджет: <b>{('до ' + fmt_single(f['budget'], 'budget')) if f['budget'] is not None else 'не задан'}</b>\n\n"
        f"<i>{status}</i>"
    )


def menu_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text="🏙 Город", callback_data="pick:city"), InlineKeyboardButton(text="🧱 Тип дома", callback_data="pick:house"))
    b.row(InlineKeyboardButton(text="💰 Цена за м²", callback_data="ask:price"), InlineKeyboardButton(text="🏢 Этажность", callback_data="ask:floors"))
    b.row(InlineKeyboardButton(text="↕️ Высота потолков", callback_data="ask:ceiling"))
    b.row(InlineKeyboardButton(text="📐 Площадь", callback_data="ask:area"), InlineKeyboardButton(text="💼 Бюджет", callback_data="ask:budget"))
    b.row(InlineKeyboardButton(text="🔎 Найти жилые комплексы", callback_data="go"))
    b.row(InlineKeyboardButton(text="♻️ Сбросить параметры", callback_data="reset"))
    return b.as_markup()


def card_text(x: Complex, area: float | None = None) -> str:
    est_block = ""
    if area:
        est = estimate(x, area)
        if est is None:
            est_block = f"\n\n📐 Примерная стоимость для {fmt_m(area)} м²: <b>нет данных о цене за м²</b>"
        else:
            note = ""
            if x.cost_r and est < x.cost_r[0]:
                note = f"\nМеньше минимальной цены квартир в ЖК (от {fmt_m(x.cost_r[0])} млн ₽)."
            elif x.cost_r and est > x.cost_r[1]:
                note = f"\nБольше максимальной цены квартир в ЖК (до {fmt_m(x.cost_r[1])} млн ₽)."
            est_block = (
                f"\n\n📐 Примерная стоимость для {fmt_m(area)} м²: <b>≈ {fmt_m(est)} млн ₽</b>\n"
                f"<i>{html.escape(x.price_text)} × {fmt_m(area)} м², ориентир по цене «от».{note}</i>"
            )
    where = " · ".join(html.escape(p) for p in (x.city, x.district) if p)
    return (
        f"<b>{html.escape(x.name)}</b>\n"
        f"{where} · {e(x.klass, 'класс не указан')}\n"
        f"Застройщик: <b>{e(x.developer)}</b>\n"
        f"💰 Цена за м²: <b>{e(x.price_text)}</b>\n"
        f"📅 Срок сдачи: <b>{e(x.completion)}</b>\n"
        f"🏢 Этажность: <b>{e(x.floors)}</b>\n"
        f"↕️ Потолки: <b>{e(x.ceiling)}</b>\n"
        f"🧱 Тип дома: <b>{e(x.house)}</b>\n"
        f"💵 Стоимость квартир в ЖК: <b>{e(x.cost)}</b>"
        f"{est_block}"
    )


def results_view(found: list[Complex], f: dict, page: int) -> tuple[str, InlineKeyboardMarkup]:
    b = InlineKeyboardBuilder()
    if not found:
        text = (
            "😕 <b>Подходящих ЖК пока нет</b>\n"
            "Измените параметры поиска. Если в таблице для ЖК нет нужного значения, "
            "он не показывается при заданном фильтре — бот ничего не додумывает за источник."
        )
        b.row(InlineKeyboardButton(text="⚙️ Изменить параметры", callback_data="menu"))
        return text, b.as_markup()

    pages = (len(found) + PAGE_SIZE - 1) // PAGE_SIZE
    page = max(0, min(page, pages - 1))
    chunk = found[page * PAGE_SIZE : (page + 1) * PAGE_SIZE]
    head = f"<b>Найдено: {len(found)} {plural(len(found))}</b>\n{html.escape(f['city'] or 'Все города')} · отобрано по заполненным параметрам"
    if pages > 1:
        head += f"\nСтраница {page + 1} из {pages}"
    text = head + "\n\n" + "\n\n".join(card_text(x, f.get("area")) for x in chunk)
    text += "\n\n<i>Описание, фото, планировки и актуальные предложения — на странице ЖК в Циан.</i>"
    for x in chunk:
        if x.source:
            name = x.name if len(x.name) <= 38 else x.name[:37] + "…"
            b.row(InlineKeyboardButton(text=f"Открыть {name} на Циан ↗", url=x.source))
    if pages > 1:
        nav = []
        if page > 0:
            nav.append(InlineKeyboardButton(text="◀️ Назад", callback_data=f"pg:{page - 1}"))
        nav.append(InlineKeyboardButton(text=f"{page + 1}/{pages}", callback_data="noop"))
        if page < pages - 1:
            nav.append(InlineKeyboardButton(text="Вперёд ▶️", callback_data=f"pg:{page + 1}"))
        b.row(*nav)
    b.row(InlineKeyboardButton(text="⚙️ Изменить параметры", callback_data="menu"))
    return text, b.as_markup()


async def edit(cb: CallbackQuery, text: str, kb: InlineKeyboardMarkup) -> None:
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest as err:
        if "message is not modified" not in str(err):
            raise


async def show_menu(target: Message | CallbackQuery, state: FSMContext, store: TableStore) -> None:
    await state.set_state(None)
    await store.get()
    text, kb = menu_text(await get_filters(state), store), menu_kb()
    if isinstance(target, CallbackQuery):
        await edit(target, text, kb)
    else:
        await target.answer(text, reply_markup=kb)


# ───────────────────────── команды ─────────────────────────
@router.message(CommandStart())
@router.message(Command("menu"))
async def cmd_start(m: Message, state: FSMContext, store: TableStore) -> None:
    await show_menu(m, state, store)


@router.message(Command("reset"))
async def cmd_reset(m: Message, state: FSMContext, store: TableStore) -> None:
    await state.clear()
    await show_menu(m, state, store)


@router.message(Command("help"))
async def cmd_help(m: Message) -> None:
    await m.answer(
        "Я помогаю подобрать жилой комплекс по данным из таблицы.\n\n"
        "/start — открыть подбор\n/reset — сбросить параметры\n\n"
        "Числовые параметры вводятся так: <code>200000-500000</code>, <code>от 300000</code> или <code>до 400000</code>. "
        "Одно число без слов — это «от».\n\n"
        "📐 <b>Площадь</b> (м²) нужна для примерной стоимости квартиры: цена за м² × площадь.\n"
        "💼 <b>Бюджет</b> (млн ₽) — максимум; ЖК, где подходящих квартир по цене нет, не показываются."
    )


@router.callback_query(F.data == "noop")
async def cb_noop(cb: CallbackQuery) -> None:
    await cb.answer()


@router.callback_query(F.data == "menu")
async def cb_menu(cb: CallbackQuery, state: FSMContext, store: TableStore) -> None:
    await cb.answer()
    await show_menu(cb, state, store)


@router.callback_query(F.data == "reset")
async def cb_reset(cb: CallbackQuery, state: FSMContext, store: TableStore) -> None:
    await state.clear()
    await cb.answer("Параметры сброшены")
    await show_menu(cb, state, store)


# ───────────────────────── выбор города / типа дома ─────────────────────────
def choice_kb(prefix: str, options: list[str], all_label: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text=all_label, callback_data=f"{prefix}:all"))
    for i in range(0, len(options), 2):
        b.row(*[InlineKeyboardButton(text=o, callback_data=f"{prefix}:{i + j}") for j, o in enumerate(options[i : i + 2])])
    b.row(InlineKeyboardButton(text="↩️ Назад", callback_data="menu"))
    return b.as_markup()


@router.callback_query(F.data.in_({"pick:city", "pick:house"}))
async def cb_pick(cb: CallbackQuery, state: FSMContext, store: TableStore) -> None:
    await cb.answer()
    await store.get()
    if cb.data == "pick:city":
        await edit(cb, "🏙 <b>Выберите город</b>", choice_kb("city", store.cities(), "🌐 Все города"))
    else:
        await edit(cb, "🧱 <b>Выберите тип дома</b>", choice_kb("house", store.houses(), "🌐 Любой тип"))


@router.callback_query(F.data.regexp(r"^(city|house):(all|\d+)$"))
async def cb_choice(cb: CallbackQuery, state: FSMContext, store: TableStore) -> None:
    key, val = cb.data.split(":")
    options = store.cities() if key == "city" else store.houses()
    if val == "all":
        await state.update_data({key: None})
    elif int(val) < len(options):  # таблица могла измениться, пока открыт список
        await state.update_data({key: options[int(val)]})
    else:
        await cb.answer("Список обновился, выберите ещё раз", show_alert=True)
        return
    await cb.answer()
    await show_menu(cb, state, store)


# ───────────────────────── ввод диапазонов ─────────────────────────
@router.callback_query(F.data.regexp(r"^ask:(price|floors|ceiling|area|budget)$"))
async def cb_ask(cb: CallbackQuery, state: FSMContext) -> None:
    key = cb.data.split(":")[1]
    await state.set_state(getattr(Form, key))
    await cb.answer()
    title, _, hint = META[key]
    cur_v = (await get_filters(state))[key]
    cur = fmt_single(cur_v, key) if key in SINGLES else fmt_range(cur_v, key)
    b = InlineKeyboardBuilder()
    b.row(InlineKeyboardButton(text="🧹 Очистить параметр", callback_data=f"clear:{key}"))
    b.row(InlineKeyboardButton(text="↩️ Назад", callback_data="menu"))
    await edit(cb, f"<b>{title}</b>\nСейчас: <b>{cur}</b>\n\nОтправьте значение сообщением.\n{hint}", b.as_markup())


@router.callback_query(F.data.regexp(r"^clear:(price|floors|ceiling|area|budget)$"))
async def cb_clear(cb: CallbackQuery, state: FSMContext, store: TableStore) -> None:
    key = cb.data.split(":")[1]
    await state.update_data({key: EMPTY[key]})
    await cb.answer("Очищено")
    await show_menu(cb, state, store)


@router.message(Form.price, F.text)
@router.message(Form.floors, F.text)
@router.message(Form.ceiling, F.text)
@router.message(Form.area, F.text)
@router.message(Form.budget, F.text)
async def got_range(m: Message, state: FSMContext, store: TableStore) -> None:
    key = STATES[await state.get_state()]
    try:
        rng = parse_single(m.text, key) if key in SINGLES else parse_user_range(m.text)
    except ValueError:
        await m.answer(f"Не получилось разобрать значение. {META[key][2]}")
        return
    await state.update_data({key: rng})
    await show_menu(m, state, store)


@router.message()
async def fallback(m: Message) -> None:
    await m.answer("Нажмите /start, чтобы открыть подбор жилых комплексов.")


# ───────────────────────── результаты ─────────────────────────
async def send_results(cb: CallbackQuery, state: FSMContext, store: TableStore, page: int) -> None:
    items = await store.get()
    f = await get_filters(state)
    text, kb = results_view(apply_filters(items, f), f, page)
    await edit(cb, text, kb)


@router.callback_query(F.data == "go")
async def cb_go(cb: CallbackQuery, state: FSMContext, store: TableStore) -> None:
    await cb.answer()
    await send_results(cb, state, store, 0)


@router.callback_query(F.data.regexp(r"^pg:\d+$"))
async def cb_page(cb: CallbackQuery, state: FSMContext, store: TableStore) -> None:
    await cb.answer()
    await send_results(cb, state, store, int(cb.data.split(":")[1]))


# ───────────────────────── запуск ─────────────────────────
async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    token = os.getenv("BOT_TOKEN")
    if not token:
        sys.exit("Не задан BOT_TOKEN. Скопируйте .env.example в .env и впишите токен от @BotFather.")
    store = TableStore(
        url=os.getenv("CSV_URL", DEFAULT_CSV_URL),
        fallback=Path(__file__).with_name("data.csv"),
        ttl=int(os.getenv("REFRESH_SECONDS", "60")),
    )
    await store.get()  # прогрев: сразу загружаем таблицу
    bot = Bot(token, default=DefaultBotProperties(parse_mode=ParseMode.HTML, link_preview_is_disabled=True))
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(router)
    await bot.set_my_commands(
        [
            BotCommand(command="start", description="Открыть подбор ЖК"),
            BotCommand(command="reset", description="Сбросить параметры"),
            BotCommand(command="help", description="Как пользоваться"),
        ]
    )
    await dp.start_polling(bot, store=store)


if __name__ == "__main__":
    asyncio.run(main())
