"""Загрузка таблицы ЖК (Google Sheets, CSV) и фильтрация.

Логика полностью повторяет сайт:
  * данные берутся из опубликованной Google-таблицы и сами обновляются;
  * если Google недоступен — используется локальный data.csv;
  * пропуски в таблице («—», «-», пустая ячейка) считаются отсутствием данных;
  * ЖК без значения параметра не попадает в выдачу, если этот параметр задан в фильтре.
"""
from __future__ import annotations

import asyncio
import csv
import io
import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

import aiohttp

log = logging.getLogger("table")

Range = tuple[float, float]


# ───────────────────────── разбор значений ─────────────────────────
def clean(value: str | None) -> str:
    """Пустая ячейка или только тире/дефисы -> пустая строка."""
    v = (value or "").strip()
    return "" if re.fullmatch(r"[\s\-–—−]*", v) else v


def parse_range(value: str) -> Range | None:
    """'11–20' -> (11, 20); '6' -> (6, 6); '3,6–7,92 м' -> (3.6, 7.92)."""
    nums = [float(x.replace(",", ".")) for x in re.findall(r"\d+(?:[.,]\d+)?", value or "")]
    return (min(nums), max(nums)) if nums else None


def parse_price(value: str) -> int:
    digits = re.sub(r"\D", "", value or "")
    return int(digits) if digits else 0


def safe_url(value: str) -> str:
    try:
        u = urlparse(value)
    except ValueError:
        return ""
    return value if u.scheme in ("http", "https") and u.netloc else ""


def _find(row: dict[str, str], prefix: str) -> str:
    """Поиск колонки по началу названия: 'Потолки' найдёт и 'Потолки(м)', и 'Потолки (м)'."""
    p = re.sub(r"\s", "", prefix).lower()
    for k, v in row.items():
        if re.sub(r"\s", "", k).lower().startswith(p):
            return v
    return ""


@dataclass(slots=True)
class Complex:
    city: str
    name: str
    developer: str
    district: str
    klass: str
    floors: str
    house: str
    ceiling: str
    price: int
    completion: str
    source: str
    cost: str = ""  # «13,05–44,04 млн ₽» — как в таблице
    price_text: str = ""
    cost_r: Range | None = field(default=None, repr=False)  # в млн ₽
    floors_r: Range | None = field(default=None, repr=False)
    ceiling_r: Range | None = field(default=None, repr=False)
    price_r: Range | None = field(default=None, repr=False)


def parse_csv(text: str) -> list[Complex]:
    reader = csv.DictReader(io.StringIO(text.lstrip("\ufeff")))
    items: list[Complex] = []
    for raw in reader:
        row = {(k or "").strip(): (v or "").strip() for k, v in raw.items()}
        name, city = clean(_find(row, "Название ЖК")), clean(_find(row, "Город"))
        if not name or not city:
            continue  # пустые строки-разделители
        price_text = clean(_find(row, "Цена от"))
        price = parse_price(price_text)
        c = Complex(
            city=city,
            name=name,
            developer=clean(_find(row, "Застройщик")),
            district=clean(_find(row, "Район")),
            klass=clean(_find(row, "Класс")),
            floors=clean(_find(row, "Этажность")),
            house=clean(_find(row, "Тип дома")),
            ceiling=clean(_find(row, "Потолки")),
            price=price,
            price_text=price_text,
            cost=clean(_find(row, "Стоимость квартиры")),
            completion=clean(_find(row, "Срок сдачи")),
            source=safe_url(clean(_find(row, "Ссылка на источник"))),
        )
        c.floors_r = parse_range(c.floors)
        c.ceiling_r = parse_range(c.ceiling)
        c.price_r = (price, price) if price else None
        c.cost_r = parse_range(c.cost) if re.search(r"млн", c.cost, re.I) else None
        items.append(c)
    return items


# ───────────────────────── стоимость квартиры ─────────────────────────
def estimate(x: Complex, area: float | None) -> float | None:
    """Примерная стоимость квартиры площадью area (м²) в млн ₽: цена «от» за м² × площадь."""
    return x.price * area / 1e6 if area and x.price else None


def low_cost(x: Complex, area: float | None) -> float | None:
    """Минимально возможная стоимость в млн ₽: большее из оценки по площади и минимума из таблицы."""
    est, lo = estimate(x, area), (x.cost_r[0] if x.cost_r else None)
    if est is None:
        return lo
    return est if lo is None else max(est, lo)


# ───────────────────────── фильтрация ─────────────────────────
def _overlap(r: Range | None, lo: float | None, hi: float | None) -> bool:
    if lo is None and hi is None:
        return True  # фильтр не задан
    if r is None:
        return False  # в таблице пропуск, а фильтр задан
    return r[1] >= (lo if lo is not None else float("-inf")) and r[0] <= (hi if hi is not None else float("inf"))


def apply_filters(items: list[Complex], f: dict) -> list[Complex]:
    """f: city, house (str | None); price / floors / ceiling ([lo, hi] с None);
    area (м²) и budget (млн ₽, «до») — числа или None."""
    pl, ph = f.get("price") or (None, None)
    fl, fh = f.get("floors") or (None, None)
    cl, ch = f.get("ceiling") or (None, None)
    area, budget = f.get("area"), f.get("budget")

    def fits_budget(x: Complex) -> bool:
        if budget is None:
            return True
        c = low_cost(x, area)
        return c is not None and c <= budget  # нет данных о стоимости -> не показываем

    return [
        x
        for x in items
        if (not f.get("city") or x.city == f["city"])
        and (not f.get("house") or x.house == f["house"])
        and _overlap(x.price_r, pl, ph)
        and _overlap(x.floors_r, fl, fh)
        and _overlap(x.ceiling_r, cl, ch)
        and fits_budget(x)
    ]


# ───────────────────────── хранилище с автообновлением ─────────────────────────
class TableStore:
    def __init__(self, url: str, fallback: Path, ttl: int = 60, retry: int = 15):
        self.url, self.fallback, self.ttl, self.retry = url, fallback, ttl, retry
        self.items: list[Complex] = []
        self.live = False
        self.updated = ""  # HH:MM последнего успешного обновления
        self._raw = ""
        self._checked = 0.0
        self._lock = asyncio.Lock()

    async def get(self) -> list[Complex]:
        """Возвращает актуальные данные; таблица перечитывается не чаще раза в ttl секунд."""
        if time.monotonic() - self._checked >= (self.ttl if self.live or not self.items else self.retry):
            async with self._lock:
                if time.monotonic() - self._checked >= (self.ttl if self.live or not self.items else self.retry):
                    await self._refresh()
        return self.items

    async def _fetch(self) -> str:
        timeout = aiohttp.ClientTimeout(total=15)
        async with aiohttp.ClientSession(timeout=timeout) as s:
            async with s.get(self.url, params={"_": int(time.time())}, headers={"Cache-Control": "no-cache"}) as r:
                r.raise_for_status()
                return await r.text(encoding="utf-8")

    async def _refresh(self) -> None:
        self._checked = time.monotonic()
        try:
            raw, live = await self._fetch(), True
        except Exception as e:  # сеть, 4xx/5xx, таймаут
            log.warning("Не удалось загрузить таблицу из Google: %s", e)
            raw, live = "", False
            if not self.items and self.fallback.exists():
                raw = self.fallback.read_text(encoding="utf-8")
        self.live = live
        if raw and raw != self._raw:
            items = parse_csv(raw)
            if items:  # пустой/битый ответ не затирает хорошие данные
                self.items, self._raw = items, raw
                log.info("Таблица обновлена: %d ЖК", len(items))
        if live:
            self.updated = time.strftime("%H:%M")

    def cities(self) -> list[str]:
        return sorted({x.city for x in self.items}, key=str.casefold)

    def houses(self) -> list[str]:
        return sorted({x.house for x in self.items if x.house}, key=str.casefold)
